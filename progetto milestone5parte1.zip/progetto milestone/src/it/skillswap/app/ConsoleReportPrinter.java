package it.skillswap.app;

import itskillswap.domain.Exchange;
import it.skillswap.domain.MatchResult;
import it.skillswap.domain.Student;

import java.util.List;
import java util.Comparator;

public class ConsoleReportPrinter {

private static final String SEPARATOR = "----------------------------------------";

public String printStudentProfile(Student student) {
StringBuilder sb = new StringBuilder();

sb.append(SEPARATOR).append("\n");
sb.append("STUDENT PROFILE").append("\n");
sb.append(SEPARATOR).append("\n");
sb.append("ID: ").append(student.getId()).append("\n");
sb.append("Nome: ").append(student.getName()).append("\n");
sb.append("Classe: ").append(student.getStudentClass()).append("\n");
sb.append("Email: ").append(student.getEmail()).append("\n");
sb.append("Rating medio: ")
.append(String.format("%.2f", student.getRatingAvg()))
.append(" (")
.append(student.getRatingCount())
.append(" recensioni)")
.append("\n");
sb.append(SEPARATOR);

return sb.toString();
}

public String printMatches(List<MatchResult> matches) {
StringBuilder sb = new StringBuilder();

sb.append(SEPARATOR).append("\n");
sb.append("MATCHES").append("\n");
sb.append(SEPARATOR).append("\n");

if (matches == null || matches.isEmpty()) {
sb.append("Nessun match trovato").append("\n");
sb.append(SEPARATOR);
return sb.toString();
}

int index = 1;
for (MatchResult match : matches) {
sb.append(index).append(")").append("\n");
sb.append(" Studente: ").append(match.getStudent().getName())
.append(" [").append(match.getStudent().getId()).append("]").append("\n");
sb.append(" Skill offerta: ").append(match.getOffer().getSkill().getName()).append("\n");
sb.append(" Livello: ").append(match.getOffer().getLevel()).append("\n");
sb.append(" Punteggio: ").append(match.getScore()).append("\n");
sb.append(" Motivo: ").append(match.getReason()).append("\n");
sb.append(SEPARATOR).append("\n");
index++;
}

return sb.toString();
}

public String printExchangeDetails(Exchange exchange) {
StringBuilder sb = new StringBuilder();

sb.append(SEPARATOR).append("\n");
sb.append("EXCHANGE DETAILS").append("\n");
sb.append(SEPARATOR).append("\n");

sb.append("ID exchange: ").append(exchange.getId()).append("\n");
sb.append("Stato: ").append(exchange.getStatus()).append("\n");
sb.append("Creato il: ").append(exchange.getCreatedAt()).append("\n");

if (exchange.getClosedAt() != null) {
sb.append("Chiuso il: ").append(exchange.getClosedAt()).append("\n");
}

sb.append("\n");
sb.append(" OFFER").append("\n");
sb.append(" - Studente: ").append(exchange.getOffer().getStudent().getName())
.append(" [").append(exchange.getOffer().getStudent().getId()).append("]").append("\n");
sb.append(" - Skill: ").append(exchange.getOffer().getSkill().getName()).append("\n");
sb.append(" - Livello: ").append(exchange.getOffer().getLevel()).append("\n");
sb.append(" - Nota: ").append(exchange.getOffer().getNote()).append("\n");

sb.append("\n");
sb.append(" REQUEST").append("\n");
sb.append(" - Studente: ").append(exchange.getRequest().getStudent().getName())
.append(" [").append(exchange.getRequest().getStudent().getId()).append("]").append("\n");
sb.append(" - Skill: ").append(exchange.getRequest().getSkill().getName()).append("\n");
sb.append(" - Livello minimo: ").append(exchange.getRequest().getMinLevel()).append("\n");
sb.append(" - Nota: ").append(exchange.getRequest().getNote()).append("\n");

sb.append(SEPARATOR);

return sb.toString();
}

public String printLeaderboard(List<Student> students) {
StringBuilder sb = new StringBuilder();

sb.append(SEPARATOR).append("\n");
sb.append("LEADERBOARD").append("\n");
sb.append(SEPARATOR).append("\n");

if (students == null || students.isEmpty()) {
sb.append("Nessuno studente disponibile").append("\n");
sb.append(SEPARATOR);
return sb.toString();
}

students.sort(
Comparator.comparingDouble(Student::getRatingAvg).reversed()
.thenComparing(Student::getName)
);

int pos = 1;
for (Student student : students) {
sb.append(pos).append(". ")
.append(student.getName())
.append(" [").append(student.getId()).append("]")
.append(" - Rating: ")
.append(String.format("%.2f", student.getRatingAvg()))
.append(" (")
.append(student.getRatingCount())
.append(" recensioni)")
.append("\n");
pos++;
}

sb.append(SEPARATOR);

return sb.toString();
}
}