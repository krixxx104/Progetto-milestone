package it.skillswap.domain;

import java.time.LocalDateTime;

public class Exchange {
    private final String id;
    private final Offer offer;
    private final Request request;
    private ExchangeStatus status;
    private final LocalDateTime createdAt;
    private LocalDateTime closedAt;

    public Exchange(String id, Offer offer, Request request) {
        this(id, offer, request, ExchangeStatus.PROPOSED, LocalDateTime.now(), null);
    }

    public Exchange(String id, Offer offer, Request request, ExchangeStatus status, LocalDateTime createdAt, LocalDateTime closedAt) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Id exchange obbligatorio");
        }
        if (offer == null) {
            throw new IllegalArgumentException("Offer obbligatoria");
        }
        if (request == null) {
            throw new IllegalArgumentException("Request obbligatoria");
        }
        if (status == null) {
            throw new IllegalArgumentException("Stato obbligatorio");
        }
        if (createdAt == null) {
            throw new IllegalArgumentException("Data creazione obbligatoria");
        }

        this.id = id;
        this.offer = offer;
        this.request = request;
        this.status = status;
        this.createdAt = createdAt;
        this.closedAt = closedAt;
    }

    public String getId() {
        return id;
    }

    public Offer getOffer() {
        return offer;
    }

    public Request getRequest() {
        return request;
    }

    public ExchangeStatus getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getClosedAt() {
        return closedAt;
    }

    public void accept() {
        if (status != ExchangeStatus.PROPOSED) {
            throw new IllegalStateException("Transizione non valida");
        }
        status = ExchangeStatus.ACCEPTED;
    }

    public void complete() {
        if (status != ExchangeStatus.ACCEPTED) {
            throw new IllegalStateException("Transizione non valida");
        }
        status = ExchangeStatus.COMPLETED;
        closedAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return id + " - offer=" + offer.getId() +
                ", request=" + request.getId() +
                ", status=" + status +
                ", createdAt=" + createdAt +
                ", closedAt=" + closedAt;
    }
}