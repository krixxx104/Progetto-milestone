package it.skillswap.app;

import it.skillswap.domain.MatchResult;
import it.skillswap.domain.Offer;
import it.skillswap.domain.Request;
import it.skillswap.domain.Skill;
import it.skillswap.domain.SkillLevel;
import it.skillswap.domain.Student;
import it.skillswap.service.MatchingService;
import it.skillswap.service.SkillSwapService;
import it.skillswap.storage.InMemoryStorage;

import java.util.List;
import java.util.Scanner;

public class SkillSwapApp {
    public static void main(String[] args) {
        SkillSwapService service = new SkillSwapService(new InMemoryStorage());
        service.seedSkills();

        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMenu();
            String choice = sc.nextLine();

            try {
                switch (choice) {
                    case "1" -> createStudent(sc, service);
                    case "2" -> listStudents(service);
                    case "3" -> listSkills(service);
                    case "4" -> addOffer(sc, service);
                    case "5" -> addRequest(sc, service);
                    case "6" -> listOffers(service);
                    case "7" -> listRequests(service);
                    case "8" -> listStudentData(sc, service);
                    case "9" -> findOneWayMatches(sc, service);
                    case "10" -> findSwapMatches(sc, service);
                    case "0" -> running = false;
                    default -> System.out.println("Scelta non valida");
                }
            } catch (Exception e) {
                System.out.println("Errore: " + e.getMessage());
            }

            System.out.println();
        }

        sc.close();
    }

    private static void printMenu() {
        System.out.println("=== SkillSwap School ===");
        System.out.println("1. Crea studente");
        System.out.println("2. Lista studenti");
        System.out.println("3. Lista skill");
        System.out.println("4. Aggiungi offer");
        System.out.println("5. Aggiungi request");
        System.out.println("6. Lista offers");
        System.out.println("7. Lista requests");
        System.out.println("8. Lista offer/request per studente");
        System.out.println("9. One-way matches");
        System.out.println("10. Swap matches");
        System.out.println("0. Esci");
        System.out.print("Scelta: ");
    }

    private static void createStudent(Scanner sc, SkillSwapService service) {
        System.out.print("Nome: ");
        String name = sc.nextLine();

        System.out.print("Classe: ");
        String studentClass = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        Student student = service.registerStudent(name, studentClass, email);
        System.out.println("Creato: " + student);
    }

    private static void listStudents(SkillSwapService service) {
        List<Student> students = service.listStudents();
        if (students.isEmpty()) {
            System.out.println("Nessuno studente presente");
            return;
        }

        for (Student s : students) {
            System.out.println(s);
        }
    }

    private static void listSkills(SkillSwapService service) {
        List<Skill> skills = service.listSkills();
        if (skills.isEmpty()) {
            System.out.println("Nessuna skill presente");
            return;
        }

        for (Skill skill : skills) {
            System.out.println(skill);
        }
    }

    private static void addOffer(Scanner sc, SkillSwapService service) {
        System.out.print("Student ID: ");
        String studentId = sc.nextLine();

        System.out.print("Skill ID: ");
        String skillId = sc.nextLine();

        System.out.print("Level (BEGINNER, INTERMEDIATE, ADVANCED): ");
        SkillLevel level = SkillLevel.valueOf(sc.nextLine().toUpperCase());

        System.out.print("Nota: ");
        String note = sc.nextLine();

        Offer offer = service.addOffer(studentId, skillId, level, note);
        System.out.println("Offer creata: " + offer);
    }

    private static void addRequest(Scanner sc, SkillSwapService service) {
        System.out.print("Student ID: ");
        String studentId = sc.nextLine();

        System.out.print("Skill ID: ");
        String skillId = sc.nextLine();

        System.out.print("Min level (BEGINNER, INTERMEDIATE, ADVANCED): ");
        SkillLevel minLevel = SkillLevel.valueOf(sc.nextLine().toUpperCase());

        System.out.print("Nota: ");
        String note = sc.nextLine();

        Request request = service.addRequest(studentId, skillId, minLevel, note);
        System.out.println("Request creata: " + request);
    }

    private static void listOffers(SkillSwapService service) {
        List<Offer> offers = service.listOffers();
        if (offers.isEmpty()) {
            System.out.println("Nessuna offer presente");
            return;
        }

        for (Offer offer : offers) {
            System.out.println(offer);
        }
    }

    private static void listRequests(SkillSwapService service) {
        List<Request> requests = service.listRequests();
        if (requests.isEmpty()) {
            System.out.println("Nessuna request presente");
            return;
        }

        for (Request request : requests) {
            System.out.println(request);
        }
    }

    private static void listStudentData(Scanner sc, SkillSwapService service) {
        System.out.print("Student ID: ");
        String studentId = sc.nextLine();

        System.out.println("--- Offers ---");
        for (Offer offer : service.listOffersByStudent(studentId)) {
            System.out.println(offer);
        }

        System.out.println("--- Requests ---");
        for (Request request : service.listRequestsByStudent(studentId)) {
            System.out.println(request);
        }
    }

    private static void findOneWayMatches(Scanner sc, SkillSwapService service) {
        System.out.print("Student ID: ");
        String studentId = sc.nextLine();

        MatchingService matchingService = new MatchingService(service.getState());
        List<MatchResult> matches = matchingService.findOneWayMatches(studentId);

        if (matches.isEmpty()) {
            System.out.println("Nessun match trovato");
            return;
        }

        for (MatchResult match : matches) {
            System.out.println(match);
        }
    }

    private static void findSwapMatches(Scanner sc, SkillSwapService service) {
        System.out.print("Student ID: ");
        String studentId = sc.nextLine();

        MatchingService matchingService = new MatchingService(service.getState());
        List<MatchResult> matches = matchingService.findSwapMatches(studentId);

        if (matches.isEmpty()) {
            System.out.println("Nessun match reciproco trovato");
            return;
        }

        for (MatchResult match : matches) {
            System.out.println(match);
        }
    }
}